
<div class="book-content">
	<h2><?php echo e($data->title); ?></h2>
	<div class="left-content">
		<p style="line-height:25px;">	
			<?php foreach($data->itineraryData as $itineraryValue): ?>
			<?php echo e($itineraryValue->event_date); ?>: <strong><?php echo e($itineraryValue->description); ?></strong><br />
			<?php endforeach; ?>
			
		</p>
	</div>
	<div class="right-image">
		<?php foreach($data->itineraryImages as $itineraryImage): ?>
		<img class="right-pic zoom-this" src="<?php echo e(url('/')); ?>/<?php echo e($data->upload_path); ?><?php echo trim($itineraryImage->image); ?>" alt="" title="">
		<?php endforeach; ?>
		
	</div>
</div>

<div class="footer">
	<img src="<?php echo e(url('/')); ?>/<?php echo $data->upload_path; ?><?php echo trim($data->logo); ?>" alt="" title="" />
</div>
<span class="page-number"><?php echo e($data->page); ?></span>