
<div class="book-content">
	<div class="left-image"> 
	</div>
	<div class="right-content">
	</div>	
</div>

<div class="footer">
	<img src="<?php echo e(url('/')); ?>/<?php echo $data->upload_path; ?><?php echo trim($data->logo); ?>" alt="" title="" />
</div>
<span class="page-number"><?php echo e($data->page); ?></span>