<div class="" style="background-color:<?php echo e($data->empty_page_color); ?>;height:100vh!important;"></div>
<span class="page-number"><?php echo e($data->page); ?></span>