<div class="fullwidth-image">

<?php echo trim($data->Mapimage);?>
	
<span class="page-number"><?php echo e($data->page); ?></span>
