<!-- Section Start -->
<section class="title-page" style="background-color:<?php echo e($data->empty_page_color); ?>;height:100vh!important;">  
<!-- Section To Display Empty -->
</section> 
<!-- Section End -->