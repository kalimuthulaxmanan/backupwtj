<!-- Section Start -->
    <table style="width:100%;height:100%;position:absolute;background-color:{{$data->empty_page_color}};">
		<tr style="">
            <td style="text-align:right">
				<h1 style="font-size: 50px;color:#fff"></h1>  
            </td>
		</tr>
    </table>
    <!-- Section End -->
	
	
	<div style="page-break-after: always;"></div>