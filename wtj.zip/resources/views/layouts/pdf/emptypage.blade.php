<!-- Section Start -->
    <table>
		<tr style="height:120px;">
            <td style="width:50%;position:relative;">
                <img src="{{url('/')}}/<?php echo $data->upload_path; ?><?php echo trim($data->logo); ?>" alt="" title="" style="width:200px;height:50px;position:absolute;bottom:15px;" />
            </td>
		</tr>
    </table>
    <!-- Section End -->
    
	
	<div style="page-break-after: always;"></div>