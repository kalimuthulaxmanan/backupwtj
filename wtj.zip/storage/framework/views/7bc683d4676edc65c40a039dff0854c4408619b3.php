<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="text-center m-b-md">
            <div class="card-header" data-background-color="purple">
                 <h4 class="title">Forgot Password</h4>                  
            </div>
            <!--    <small>This is the best app ever!</small>-->
            </div>
            <div class="hpanel">
                <div class="panel-body">
                        <form  id="loginForm" method="post" action="<?php echo e(url('/forgetpassword')); ?>">
							     <?php echo csrf_field(); ?>

                            <?php if(Session::has('invalidemail')): ?>
                              <body onload="demo.showNotification('top','center',4,'Invalid Email')"/>
                            <?php endif; ?>
                            <?php if(Session::has('successemail')): ?>
                              <body onload="demo.showNotification('top','center',2,'The password has sent to your registered email.')"/>
                                <?php endif; ?>
                            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                <label class="control-label" for="email">Email</label>
                                <input type="email" title="Please enter you email" required="" value="" name="email" id="email" class="form-control">
                                <?php if($errors->has('email')): ?>
                                    <span style="color:red">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>

                            </div>
                            <button type="submit" class="btn btn-success btn-block">Submit</button>
							<a class="btn btn-default btn-block" href="<?php echo e(url('/login')); ?>">Login</a>
                            <!--<a class="btn btn-default btn-block" href="<?php echo e(url('/register')); ?>">Register</a>-->

                        </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>