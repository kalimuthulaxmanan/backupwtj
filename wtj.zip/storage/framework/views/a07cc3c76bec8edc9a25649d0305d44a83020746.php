<!-- Section Start -->	
    <table class="padd-left">
		<tr style="">
            <td style="width:60%;vertical-align: top;">
				<h1 style="font-size: 50px;"><?php echo e($data->title); ?></h1> <br />
				<?php foreach($data->detailitineraryDatas as $detail_itineraryData): ?>
				<span><b><?php echo e($detail_itineraryData->event_date); ?></b></span><br /><br />
				<span>
					&nbsp; &nbsp; &nbsp; - &nbsp; <?php echo nl2br($detail_itineraryData->description); ?><br />
					
					</span> 
			<?php endforeach; ?>	
            </td>
            <td style="width:40%;text-align:right">
				<?php foreach($data->detailitineraryImages as $detailitineraryImage): ?>
                <img src="<?php echo e(url('/')); ?>/<?php echo e($data->upload_path); ?>/<?php echo trim($detailitineraryImage->image); ?>" alt="" title="" style="width:300px;" /><br />
				<?php endforeach; ?>
                
            </td>
		</tr>
    </table>
    <table style="height:50px;position:absolute;bottom:15px">
		<tr style="">
            <td style="width:50%;">
                <img src="<?php echo e(url('/')); ?>/<?php echo $data->upload_path; ?><?php echo trim($data->logo); ?>" alt="" title="" style="width:200px;height:50px;" />
            </td>
		</tr>
    </table>
    <!-- Section End -->
	
	
	<div style="page-break-after: always;"></div>