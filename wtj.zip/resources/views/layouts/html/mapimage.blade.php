<!-- Section Start -->
	<section class="">        
		<div class="fullwidthimage change-image">
			<div style="width: 100%; height: 720px;">
		  {!!$data->Mapimage!!}
		</div>
		</div>
	</section>	
<!-- Section End -->