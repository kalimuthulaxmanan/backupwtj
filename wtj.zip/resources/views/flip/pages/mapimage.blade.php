<div class="fullwidth-image">

<?php echo trim($data->Mapimage);?>
	
<span class="page-number">{{$data->page}}</span>
