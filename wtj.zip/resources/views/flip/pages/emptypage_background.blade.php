<div class="" style="background-color:{{$data->empty_page_color}};height:100vh!important;"></div>
<span class="page-number">{{$data->page}}</span>