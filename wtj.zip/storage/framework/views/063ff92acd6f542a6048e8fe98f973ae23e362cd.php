<!-- Section Start -->
<section class="">        
	<div class="fullwidthimage change-image">
		<?php foreach($data->fullImages as $fullimage): ?>
		<img src="<?php echo e(url('/')); ?>/<?php echo e($data->upload_path); ?><?php echo trim($fullimage->image); ?>" id ="image<?php echo e($fullimage->id); ?>" alt="" title="" />
		<div class="img-overlay">
			<a onclick="newFunction('image<?php echo e($fullimage->id); ?>',<?php echo e($fullimage->id); ?>)" data-toggle="modal" data-target="#myModal" href="">Change Image</a>
		</div>
		<?php endforeach; ?>
	</div>
</section>	
<!-- Section End -->