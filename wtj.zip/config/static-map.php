<?php
return [
    'key'         => env('GOOGLE_MAP', null),
    'width'       => 600,
    'height'      => 400,
    'mapType'     => 'roadmap',
    'imageFormat' => 'png',
    'zoom'        => 14,
];